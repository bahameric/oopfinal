# -*- coding: utf-8 -*-
"""
Created on Tue May 27 07:15:35 2025

@author: furkan
"""

import sys
import random
from PyQt5.QtWidgets import QApplication, QWidget
from ui_form import Ui_Form

class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.numbers = []

        self.ui.combo_sort.setEnabled(False)
        self.ui.btn_generate.clicked.connect(self.generate_numbers)
        self.ui.radio_max.toggled.connect(self.show_max)
        self.ui.radio_min.toggled.connect(self.show_min)
        self.ui.radio_sort.toggled.connect(self.sort_trigger)
        self.ui.combo_sort.currentTextChanged.connect(self.sort_numbers)
        self.ui.radio_reverse.toggled.connect(self.reverse_numbers)

    def generate_numbers(self):
        self.numbers = [random.randint(0, 99) for _ in range(40)]
        self.ui.text_numbers.setPlainText(str(self.numbers))
        self.ui.radio_max.setEnabled(True)
        self.ui.radio_min.setEnabled(True)
        self.ui.radio_sort.setEnabled(True)
        self.ui.radio_reverse.setEnabled(True)
        self.ui.combo_sort.setEnabled(False)
        self.ui.label_status.setText("Numbers are generated.")

    def show_max(self):
        if self.ui.radio_max.isChecked():
            result = max(self.numbers)
            self.ui.text_result.setPlainText(str(result))
            self.ui.label_status.setText("Maximum number is determined")

    def show_min(self):
        if self.ui.radio_min.isChecked():
            result = min(self.numbers)
            self.ui.text_result.setPlainText(str(result))
            self.ui.label_status.setText("Minimum number is determined")

    def sort_trigger(self):
        if self.ui.radio_sort.isChecked():
            self.ui.combo_sort.setEnabled(True)
            self.sort_numbers()
        else:
            self.ui.combo_sort.setEnabled(False)

    def sort_numbers(self):
        if self.ui.radio_sort.isChecked():
            order = self.ui.combo_sort.currentText()
            if order == "Ascending":
                result = sorted(self.numbers)
                self.ui.label_status.setText("Numbers are sorted in ascending order")
            else:
                result = sorted(self.numbers, reverse=True)
                self.ui.label_status.setText("Numbers are sorted in descending order")
            self.ui.text_result.setPlainText(str(result))

    def reverse_numbers(self):
        if self.ui.radio_reverse.isChecked():
            result = list(reversed(self.numbers))
            self.ui.text_result.setPlainText(str(result))
            self.ui.label_status.setText("Numbers are reversed")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())
