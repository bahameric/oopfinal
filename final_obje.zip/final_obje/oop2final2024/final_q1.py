# -*- coding: utf-8 -*-
"""
Created on Tue May 27 05:05:53 2025

@author: furkan
"""

class Player:
    def __init__(self, firstName, lastName, age, nation):#private method
    #private method iç işlemleri yapar ve encapsulation sağlar.
    #sadece sınıf içinde çağrılabilir
        self.__firstName = firstName
        self.__lastName = lastName
        self.__age = age
        self.__nation = nation
   ##Accessor getter  
    def get_firstName(self):
        return self.__firstName 
    def get_lastName(self):
        return self.__lastName
    def get_age(self):
        return self.__age
    def get_nation(self):
        return self.__nation
    
    #setter mutator
    def set_firstName(self, firstName):
        self.__firstName = firstName
    def set_lastName(self, lastName):
        self.__lastName = lastName
    def set_age(self, age):
        self.__age = age
    def set_nation(self, nation):
        self.__nation = nation
        
    #getter üzerinden erişerek print fonksiyonu yazmak
    #firstname private tanımlandığı için doğrudan çağrılamaz
    #self.firstName şeklinde tanımlansa doğrudan self.firstName şeklinde çağrılabilirdi
    def print_player(self):
        print("First Name:", self.get_firstName())
        print("Last Name:", self.get_lastName())
        print("Age:", self.get_age())
        print("Nation:", self.get_nation())

class LeaguePlayer(Player):
    def __init__(self, firstName, lastName, age, nation,
                 branch, game_num, win_num, lost_num, player_score):
        #üst sınıfın bütün methodlarını ve özelleiklerini alt sınıfa alır.
        super().__init__(firstName, lastName, age, nation)
        self.__branch = branch
        self.__game_num = game_num
        self.__win_num = win_num
        self.__lost_num = lost_num
        self.__player_score = player_score
    def get_branch(self):
        return self.__branch
    def set_brach(self, b):
        self.__branch = b
    def get_game_num(self):
        return self.__game_num
    def get_win_num(self):
        return self.__win_num
    def get_lost_num(self):
        return self.__lost_num
    def get_player_score(self):
        return self.__player_score
    
    def print_player(self):#polymorphism örneği.
        super().print_player() # super classın print_player methodunu inhariye ettil
        print("Branch:", self.get_branch())
        print("Games Played:",self.get_game_num())
        print("Wins:", self.get_win_num())
        print("Losses:", self.get_lost_num())
        print("Score:", self.get_player_score())
        
    def statistics(self):
        stat = self.get_player_score() / self.get_game_num()
        print("League Statistics:", stat)
    def points(self):
        return 10 * self.get_game_num() + 3 * self.get_win_num() - 2 * self.get_lost_num()

class NationalPlayer(LeaguePlayer):
    def __init__(self, firstName, lastName, age, nation,
                 branch, game_num, win_num, lost_num, player_score,
                 nationalGame_num, nationalPlayer_score):
        super().__init__(firstName, lastName, age, nation, branch, game_num, win_num, lost_num, player_score)
        self.__nationalGame_num = nationalGame_num
        self.__nationalPlayer_score = nationalPlayer_score
        
    def get_nationalGame_num(self):
        return self.__nationalGame_num
    def set_nationalGame_num(self, value):
        self.__nationalGame_num = value
    def get_nationalPlayer_score(self):
        return self.__nationalPlayer_score
    def set_nationalPlayer_score(self,value):
        self.__nationalPlayer_score = value
    
    def print_plyer(self):#polymophisim
        super().print_player() # League player print_player methodunu alır
        print("National Games:", self.get_nationalGame_num())
        print("National Score:", self.get_nationalPlayer_score())
        
    def statistics(self):
        stats = self.get_nationalPlayer_score() / self.get_nationalGame_num()
        print("National Statistics:", stats)
    
    def points(self):
        base_points = super().points()
        total_points = 15 * self.get_nationalGame_num() + base_points
        print("Total Points:", total_points)
        return total_points
    
    
    