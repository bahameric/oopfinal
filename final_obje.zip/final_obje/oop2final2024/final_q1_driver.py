from final_q1 import Player, LeaguePlayer, NationalPlayer

def main():
    # 1. Player nesnesi
    p1 = Player("Fabian", "Delph", 22, "England")
    p1.print_player()
    print()

    # 2. LeaguePlayer nesnesi
    p2 = LeaguePlayer("Tony", "Parker", 28, "France", "Basketball", 36, 17, 19, 22)
    p2.print_player()
    p2.statistics()
    print("Player points:", p2.points())
    print()

    # 3. NationalPlayer nesnesi
    p3 = NationalPlayer("Jordan", "Larson", 22, "USA", "Volleyball", 21, 16, 5, 36, 8, 3)
    p3.print_player()
    p3.statistics()
    print("Player points:", p3.points())

if __name__ == "__main__":
    main()
