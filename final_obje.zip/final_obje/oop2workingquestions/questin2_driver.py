# -*- coding: utf-8 -*-
"""
Created on Tue May 27 08:39:40 2025

@author: furkan
"""

import sys
from PyQt5.QtWidgets import QApplication, QWidget
from form import Ui_Form  # ui_prime.py içindeki arayüz sınıfı

class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        # Buton bağlantısı
        self.ui.pushButton.clicked.connect(self.run_clicked)

    def run_clicked(self):
        try:
            # Kullanıcıdan sayı al ve int'e çevir
            n = int(self.ui.line_input.text())
            primes = self.calculate_primes(n)

            # ComboBox'tan seçim
            choice = self.ui.comboBox.currentText()

            if choice == "Print the text box":
                self.print_text_box(primes)
                self.ui.label_status.setText("Printing the text box")
            elif choice == "Write the file":
                self.print_file(primes)
                self.ui.label_status.setText("Writing to file")
        except ValueError:
            self.ui.label_status.setText("ERROR: Input must be valid number")

    def calculate_primes(self, n):
        primes = []
        for num in range(2, n):
            is_prime = True
            for i in range(2, int(num ** 0.5) + 1):
                if num % i == 0:
                    is_prime = False
                    break
            if is_prime:
                primes.append(num)
        return primes

    def print_text_box(self, primes):
        self.ui.text_result.setPlainText('\n'.join(str(p) for p in primes))

    def print_file(self, primes):
        with open("prime_numbers.txt", "w") as f:
            for p in primes:
                f.write(f"{p}\n")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())
