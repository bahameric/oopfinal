# -*- coding: utf-8 -*-
"""
Created on Tue May 27 07:53:49 2025

@author: furkan
"""

class Employee:
    def __init__(self, firstName, lastName):
        self.__firstName = firstName
        self.__lastName = lastName
     # Accessor (getter) metotları
    def get_firstName(self):
        return self.__firstName

    def get_lastName(self):
        return self.__lastName
    
    # Mutator (setter) metotları
    def set_firstName(self, firstName):
        self.__firstName = firstName

    def set_lastName(self, lastName):
        self.__lastName = lastName
    
    # Yazdırma metodu (polymorphic olarak override edilecek)
    def print_employee(self):
        print("First Name:", self.get_firstName())
        print("Last Name:", self.get_lastName())
        
class CommissionEmployee(Employee):
    def __init__(self, firstName, lastName, commission_rate, gross_sales):
        super().__init__(firstName, lastName)  # Inheritance ile üst sınıf init çağır
        self.__commission_rate = commission_rate
        self.__gross_sales = gross_sales
    # Getter'lar
    def get_commission_rate(self):
        return self.__commission_rate

    def get_gross_sales(self):
        return self.__gross_sales

    # Setter'lar
    def set_commission_rate(self, commission_rate):
        self.__commission_rate = commission_rate

    def set_gross_sales(self, gross_sales):
        self.__gross_sales = gross_sales
        
    # Kazancı hesapla
    def earnings(self):
        return self.__commission_rate * self.__gross_sales

    # Yazdırma (polymorphism)
    def print_employee(self):
        super().print_employee()  # Üst sınıftaki bilgileri yaz
        print("Commission Rate:", self.get_commission_rate())
        print("Gross Sales:", self.get_gross_sales())
        print("Earnings:", self.earnings())
        
class BasePlusCommissionEmployee(CommissionEmployee):
    def __init__(self, firstName, lastName, commission_rate, gross_sales, base_salary):
        super().__init__(firstName, lastName, commission_rate, gross_sales)
        self.__base_salary = base_salary

    def get_base_salary(self):
        return self.__base_salary

    def set_base_salary(self, base_salary):
        self.__base_salary = base_salary

    def earnings(self):
        return self.get_base_salary() + super().earnings()
    # Yazdırma
    def print_employee(self):
        super().print_employee()
        print("Base Salary:", self.get_base_salary())
        print("Total Earnings:", self.earnings())