# -*- coding: utf-8 -*-
"""
Created on Tue May 27 08:01:53 2025

@author: furkan
"""

from working_questions_1 import Employee, CommissionEmployee, BasePlusCommissionEmployee

def main():
    e1 = Employee("Ali", "Yılmaz")
    e2 = CommissionEmployee("Ayşe", "Kara", 0.10, 5000)
    e3 = BasePlusCommissionEmployee("Mehmet", "Demir", 0.10, 5000, 1000)

    employee_list = [e1, e2, e3]

    for emp in employee_list:
        print("\n--- Employee Info ---")
        emp.print_employee()

if __name__ == "__main__":
    main()

##UML 
"""
Methodların değişkenlerine dikkat et self hariç hepsini yaz.
GENEL YAPI:
 +-----------------------+         ← Sınıf adı
| ClassName             |
+-----------------------+         ← Özellikler (attributes)
| __attribute1          |
| __attribute2          |
+-----------------------+         ← Metotlar (constructor, setters, getters)
| __init__(...)         |
| set_attr()            |
| get_attr()            |
| method_name()         |
+-----------------------+
*****************************************
+------------------------+
| Employee               |
+------------------------+         
| __firstName            |
| __lastName             |
+------------------------+
| __init__(firstName, lastName) |
| set_firstName(firstName)      |
| set_lastName(lastName)        |
| get_firstName()               |
| get_lastName()                |
| print_employee()              |
+------------------------+
********************************************
+------------------------------+
| CommissionEmployee           |
+------------------------------+
| __commission_rate            |
| __gross_sales                |
+------------------------------+
| __init__(firstName, lastName, commission_rate, gross_sales) |
| set_commission_rate(commission_rate)                        |
| set_gross_sales(gross_sales)                                |
| get_commission_rate()                                       |
| get_gross_sales()                                           |
| earnings()                                                  |
| print_employee()                                            |
+------------------------------+
*****************************************************
+--------------------------------------+
| BasePlusCommissionEmployee           |
+--------------------------------------+
| __base_salary                        |
+--------------------------------------+
| __init__(firstName, lastName, commission_rate, gross_sales, base_salary) |
| set_base_salary(base_salary)                                          |
| get_base_salary()                                                     |
| earnings()                                                            |
| print_employee()                                                      |
+--------------------------------------+
******************************************
"""
